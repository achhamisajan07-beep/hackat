/**
 * SDG 8 Platform - Main Logic
 * Uses LocalStorage to simulate a backend for User Profiles, Jobs, and Applications.
 */

const App = {
    init() {
        this.injectNavbar();
        this.checkAuth();
    },

    // Inject shared navbar into any page with <div id="navbar-placeholder"></div>
    injectNavbar() {
        const navbarHTML = `
            <nav class="navbar">
                <div class="container">
                    <a href="index.html" class="logo">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                        <span>DecentWork<span style="color:var(--secondary)">8</span></span>
                    </a>
                    <ul class="nav-links">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="jobs.html">Find Jobs</a></li>
                        <li><a href="post-job.html">Post a Job</a></li>
                        <li><a href="wallet.html">Wallet & Loans</a></li>
                    </ul>
                    <div class="auth-buttons">
                        <a href="profile.html" class="btn btn-outline" id="profile-btn">Login / Profile</a>
                    </div>
                </div>
            </nav>
        `;

        const placeholder = document.getElementById('navbar-placeholder');
        if (placeholder) {
            placeholder.innerHTML = navbarHTML;
            this.highlightActivePage();
        }
    },

    highlightActivePage() {
        const currentPath = window.location.pathname.split('/').pop() || 'index.html';
        const links = document.querySelectorAll('.nav-links a');
        links.forEach(link => {
            if (link.getAttribute('href') === currentPath) {
                link.classList.add('active');
            }
        });
    },

    // Mock Data for Jobs
    mockJobs: [
        { title: "Senior React Developer", company: "Tech Nepal Solutions", location: "Kathmandu", salary: "80,000", type: "high-skilled", tags: ["Remote", "Safe Job"] },
        { title: "Plumber", company: "FixIt Fast", location: "Lalitpur", salary: "25,000", type: "low-skilled", tags: ["Urgent", "Safe Job"] },
        { title: "Accountant", company: "Himalayan Bank", location: "Kathmandu", salary: "45,000", type: "high-skilled", tags: ["Finance"] },
        { title: "Construction Worker", company: "City Builders", location: "Pokhara", salary: "30,000", type: "low-skilled", tags: ["Daily Pay"] },
        { title: "Graphic Designer", company: "Creative Hub", location: "Remote", salary: "40,000", type: "high-skilled", tags: ["Flexible"] }
    ],

    renderJobs(filterType = 'all') {
        const jobList = document.getElementById('job-list');
        if (!jobList) return;

        jobList.innerHTML = '';

        const jobs = this.mockJobs.filter(job => {
            if (filterType === 'all') return true;
            if (filterType === 'remote') return job.location === 'Remote';
            return job.type === filterType;
        });

        jobs.forEach(job => {
            const card = document.createElement('div');
            card.className = 'job-card';
            card.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:start;">
                    <h3 style="color:var(--primary)">${job.title}</h3>
                    <span style="font-weight:700; color:var(--text-main)">NPR ${job.salary}</span>
                </div>
                <p style="color:var(--text-muted); margin-bottom:0.5rem;">${job.company} • ${job.location}</p>
                
                <div style="margin-bottom:1rem;">
                    ${job.tags.map(tag => `<span class="tag ${tag === 'Safe Job' ? 'safe-job' : ''}">${tag}</span>`).join('')}
                </div>
                
                <button class="btn btn-outline" style="width:100%; font-size:0.9rem;" onclick="alert('Applied to ${job.title}!')">Apply Now</button>
            `;
            jobList.appendChild(card);
        });
    },

    checkAuth() {
        const user = localStorage.getItem('sdg8_user');
        const profileBtn = document.getElementById('profile-btn');
        if (user && profileBtn) {
            const userData = JSON.parse(user);
            profileBtn.textContent = userData.name || 'My Profile';
            profileBtn.classList.add('logged-in');
        }
    },

    checkLoanEligibility() {
        const resultDiv = document.getElementById('loan-result');
        if (!resultDiv) return;

        resultDiv.style.display = 'block';
        resultDiv.innerHTML = '<p>Analyzing work history and credit score...</p>';

        setTimeout(() => {
            resultDiv.innerHTML = `
                <div style="padding: 1rem; background: #FFF7ED; border: 1px solid #FFEDD5; border-radius: 8px;">
                    <h3 style="color: #9A3412; margin-bottom: 0.5rem;">🎉 You are Eligible!</h3>
                    <p style="font-size: 0.9rem; margin-bottom: 1rem;">Based on your consistent mock work history, you qualify for:</p>
                    <ul style="margin-left: 1.5rem; margin-bottom: 1rem; font-size: 0.9rem;">
                        <li><strong>Micro-Enterprise Loan:</strong> Up to NPR 200,000</li>
                        <li><strong>Interest Rate:</strong> 7.5% (Subsidized)</li>
                    </ul>
                    <button class="btn btn-primary" style="font-size: 0.8rem;" onclick="alert('Application Sent to Partner Bank!')">Apply for Loan</button>
                </div>
            `;
        }, 1500);
    },

    logout() {
        localStorage.removeItem('sdg8_user');
        window.location.href = 'index.html';
    }
};

document.addEventListener('DOMContentLoaded', () => {
    App.init();

    // Filter Logic
    const filterBtns = document.querySelectorAll('.filter-btn');
    if (filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                App.renderJobs(btn.dataset.filter);
            });
        });
    }
});
